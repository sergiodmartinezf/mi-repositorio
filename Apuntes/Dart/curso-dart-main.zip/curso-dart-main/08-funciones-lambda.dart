//Funciones Lambda o Anónimas
void main() {
  //Función anónima
  var suma = (int a, int b) => a + b;

  // Llamada a la función anónima
  print(suma(10, 20));
}
