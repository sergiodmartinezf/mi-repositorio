void main(){
  print('Hola Mundo');
}